#!/usr/bin/env bash
VERSION=$1
cat ../swagger/swagger_without-ibm.yaml swagger-ibm-template.yaml > aux.yaml
sed -n 'H;${x;s/^\n//;s/description: .*$/x-ibm-name: mrs-esis-core\'$'\n  &/;p;}' aux.yaml > ../swagger/mrs-esis-core_$VERSION.yaml
rm aux.yaml
rm ../swagger/swagger_without-ibm.yaml