package functional;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.EsisCoreEngineClient;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.HelperUtilities;

import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestClientResponseException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import org.junit.jupiter.api.Test;

@ActiveProfiles("test")
public class ExceptionHandlingFunctionalTest extends FunctionalTest {

    @Test
    public void testWeGetBadRequestWhenEmptyBody() {

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("empty-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(406);
    }

    @Test
    public void testWhenAllDownstreamServicesReturn404() {

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500);

    }

    @Test
    public void testWhenGMCReturns404() {

        stubEsisDocument();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Downstream service unavailable")
                );

    }

    @Test
    public void testWhenGMCReturnsCoreServiceException() {

        stubEsisDocument();
        stubGMCEmptyResp();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500);

    }

    @Test
    public void testWhenGMCReturnsJSONException() {

        stubErrorEsisDocument();
        stubGMCOK();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500);

    }

    @Test
    public void testWhenEsisReturnsBlank() {

        stubEsisDocumentBlank();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Invalid/Empty response from ESIS Core service")
                );

    }


    @Test
    public void testWhenEsiseturnsBadRequest() {

        stubEsisDocumentBadRequest();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(400).
                body(
                        "errorResponse.error", equalTo("Bad Request to Downstream service")
                );
    }
    @Test
    public void testWhenGMCeturnsBadRequest() {

        stubEsisDocument();
        stubGMCBadRequest();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(400).
                body(
                        "errorResponse.error", equalTo("Bad Request to Downstream service")
                );
    }
    @Test
    public void testWhenVaulteturnsBadRequest() {

        stubEsisDocument();
        stubGMCOK();
        stubVaultIngestBadRequest();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(400).
                body(
                        "errorResponse.error", equalTo("Bad Request to Downstream service")
                );
    }

    @Test
    public void testWhenGMCReturns503() {

        stubEsisDocument();
        stubGMCUnavailable();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Internal error in downstream service")

                );

    }

    @Test
    public void testWhenVault404() {

        stubEsisDocument();
        stubGMCOK();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Downstream service unavailable")
                );

    }

    @Test
    public void testWhenVaultIngestIsDown() {

        stubEsisDocument();
        stubGMCOK();
        stubVaultIngestDown();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Internal error in downstream service")
                );

    }
    @Test
    public void testWhenVaultRetrieveIsDown() {

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/123", serverPort);

        given().
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                get(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Downstream service unavailable")
                );

    }
    @Test
    public void testRestExceptionRetrieveIsDown() {

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/123", serverPort);

        given().
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                get(url).
                then().
                statusCode(500).
                body(
                        "errorResponse.error", equalTo("Downstream service unavailable")
                );

    }

    @Test
    public void testCoreServiceException() {

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/123", serverPort);
        stubEsisDocument();
        stubGMCOK();
        stubVaultRetrieveRedirect();
        given().
                header(authorizationHeader).

                when().
                get(url).
                then().
                statusCode(500)
               ;

    }

    @Test
    public void testCoreServiceRestException() {

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/123", serverPort);
        stubEsisDocument();
        stubGMCOK();
        stubVaultRestClientEx();
        given().
                header(authorizationHeader).

                when().
                get(url).
                then().
                statusCode(500)
        ;

    }

    @Test
    public void testEmptyPds() {
        stubEsisDocument();
        stubGMCOK();
        stubVaultRetrieveEmptyPDFOK();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/12345", serverPort);

        given().
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                get(url).
                then().
                statusCode(500);
    }
    @Test
    public void testNotFoundPds() {
        stubEsisDocument();
        stubGMCOK();
        stubVaultRetrieveNotFound();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/12345", serverPort);

        given().
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                get(url).
                then().
                statusCode(500);
    }

    @Test
    public void testRestResponseHandler() {
        HelperUtilities helperUtilities = new HelperUtilities();
        EsisCoreEngineClient esisCoreEngineClient = new EsisCoreEngineClient();
        try {
            helperUtilities.handleRestException("12345",new Response(),new RestClientResponseException("Exception",404,"message",null,null,null), esisCoreEngineClient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
