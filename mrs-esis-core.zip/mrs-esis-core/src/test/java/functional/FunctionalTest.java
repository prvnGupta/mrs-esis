package functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.santanderuk.loan.mortgage.esis.pos.mrs.MRSAggregationServiceApplication;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.config.JsonPathConfig;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static io.restassured.config.EncoderConfig.encoderConfig;
import static io.restassured.config.JsonConfig.jsonConfig;
import static io.restassured.config.RestAssuredConfig.newConfig;


@ContextConfiguration(initializers = FunctionalTest.RandomPortInitailizer.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = MRSAggregationServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class FunctionalTest {

    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";

    public Header authorizationHeader;

    @LocalServerPort
    protected String serverPort;

    @Value("${wiremock.port}")
    protected int wiremockPort;

    private WireMockServer wireMockServer;

    @BeforeEach
    public void setUp() {
        RestAssured.config =
                newConfig().jsonConfig(jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));
        RestAssured.config =
                newConfig().encoderConfig(encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false));


        wireMockServer = new WireMockServer(wiremockPort);
        wireMockServer.start();

        authorizationHeader = new Header("authorization", jwtAuth);
    }

    @AfterEach
    public void tearDown() {
        wireMockServer.stop();
    }

    protected void stubEsisDocument(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-sale-agreement/v1/esis-document"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("kfi-response.json"))));
    }

    protected void stubErrorEsisDocument(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-sale-agreement/v1/esis-document"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("kfi-response-error.json"))));
    }

    protected void stubEsisDocumentBlank(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-sale-agreement/v1/esis-document"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("")));
    }

    protected void stubEsisDocumentBadRequest(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-sale-agreement/v1/esis-document"))
                .willReturn(aResponse()
                        .withStatus(400)
                        .withHeader("Content-Type", "application/json")));
    }

    protected void stubGMCUnavailable(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .willReturn(aResponse()
                        .withStatus(503)));
    }
    protected void stubGMCBadRequest(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .willReturn(aResponse()
                        .withStatus(400)));
    }

    protected void stubGMCOK(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                .withBody(readFileContents("gmc-response.json"))));
    }

    protected void stubGMCEmptyResp(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/doc-mgt-arch/cresp-services/v1/gen-doc-base64"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));

    }

    protected void stubVaultIngestDown(){
        wireMockServer.stubFor(post(urlPathEqualTo("/nuxeoServices/ingestDocument"))
                .willReturn(aResponse()
                        .withStatus(503)));
    }


    protected void stubVaultIngestOk(){
        wireMockServer.stubFor(post(urlPathEqualTo("/nuxeoServices/ingestDocument"))
                .willReturn(aResponse()
                        .withStatus(200)));
    }

    protected void stubVaultIngestBadRequest(){
        wireMockServer.stubFor(post(urlPathEqualTo("/nuxeoServices/ingestDocument"))
                .willReturn(aResponse()
                        .withStatus(400)));
    }
    protected void stubVaultRetrieveOK(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("vault-pdf.json"))));
    }
    protected void stubVaultRestClientEx(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(503)));
                       // .withHeader("Content-Type", "application/json")
                       // .withBody(readFileContents("vault-empty-resp.json"))));
    }
    protected void stubVaultRetrieveEmptyPDFOK(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));
    }

    protected void stubVaultRetrieveRedirect(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(302)
                        .withHeader("Content-Type", "application/json")));
    }
    protected void stubVaultRetrieveNotFound(){
        wireMockServer.stubFor(post(urlPathEqualTo("/sanuk/internal/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withHeader("Content-Type", "application/json")));
    }

    protected void stubRetrieveAPIPDF(){
        wireMockServer.stubFor(get(urlPathEqualTo("/sanuk/internal/vault/document/retrieveByReference"))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withHeader("Content-Type", "application/json")));
    }

    protected static String readFileContents(String filename) {
        InputStream resource = null;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    public static class RandomPortInitailizer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {

            int wiremockRandomPort = SocketUtils.findAvailableTcpPort();

            String posServiceUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-sale-agreement/v1/esis-document", wiremockRandomPort);
            String retrieveKfiUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-sale-agreement/v1/retrieve-kfi", wiremockRandomPort);
            String gmcCoreServiceURL = String.format("http://localhost:%d/sanuk/internal/doc-mgt-arch/cresp-services/v1/gen-doc-base64", wiremockRandomPort);
            String vaultDocumentServiceCreateURL = String.format("http://localhost:%d/nuxeoServices/ingestDocument", wiremockRandomPort);
            String vaultDocumentServiceRetrieveURL = String.format("http://localhost:%d/sanuk/internal/vault/document/retrieveByReference", wiremockRandomPort);
            String vaultDocumentServiceSearchURL = String.format("http://localhost:%d/sanuk/internal/vault/documents/search", wiremockRandomPort);


            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core-api.service.pos-core-service.uri=" + posServiceUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core-api.service.pos-core-service.retrieve-kfi-uri=" + retrieveKfiUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core-api.service.gmc-core-service.uri-base64=" + gmcCoreServiceURL);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core-api.service.vault-document-service.uri-ingest=" + vaultDocumentServiceCreateURL);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core-api.service.vault-document-service.uri-retrieve=" + vaultDocumentServiceRetrieveURL);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "core-api.service.vault-document-service.uri-search=" + vaultDocumentServiceSearchURL);


            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "wiremock.port=" + wiremockRandomPort);


        }

    }
}
