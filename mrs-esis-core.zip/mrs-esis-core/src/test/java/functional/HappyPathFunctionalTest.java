package functional;


import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class HappyPathFunctionalTest extends FunctionalTest {

    @Test
    public void testHappyPath() {

        stubEsisDocument();
        stubGMCOK();
        stubVaultIngestOk();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/create", serverPort);

        given().
                body(readFileContents("KFI-request.xml")).
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                post(url).
                then().
                statusCode(201).
                body(
                        "Response.KFIData.@KFIId", equalTo("F10009C4D948470588A38077854C1FBD")
                );
    }
    @Test
    public void testHappyPathPds() {
        stubEsisDocument();
        stubGMCOK();
        stubVaultRetrieveOK();

        String url = String.format("http://localhost:%s/mrs-esis-core/esis/12345", serverPort);

        given().
                header(authorizationHeader).
                header("Accept", MediaType.APPLICATION_XML_VALUE).
                header("Content-Type", MediaType.APPLICATION_XML_VALUE).
                when().
                get(url).
                then().
                statusCode(200).
                body(
                        "Response.KFIData.@KFIId", equalTo("12345")
                );
    }
}
