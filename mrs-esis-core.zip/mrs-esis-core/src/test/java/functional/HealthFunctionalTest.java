package functional;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static io.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;

@ActiveProfiles("test")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;

    @BeforeEach
    public void setup() {
        healthUrl = String.format("http://localhost:%s/mrs-esis-core/healthz", serverPort);
    }

    @Test
    public void customHealthCheckReturnsUp() throws Exception {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));

    }

}
