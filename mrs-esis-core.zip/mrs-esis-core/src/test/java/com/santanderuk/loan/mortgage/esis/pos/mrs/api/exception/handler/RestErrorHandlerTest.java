package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.handler;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.BadRequestException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ServerException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.BAD_REQUEST;


@ExtendWith(MockitoExtension.class)
public class RestErrorHandlerTest {

    @Mock
    ClientHttpResponse clientHttpResponse;

    @InjectMocks
    RestErrorHandler restErrorHandler;


    @Test
    public void testWeGetBadRequestException() throws IOException {

        when(clientHttpResponse.getStatusCode()).thenReturn(BAD_REQUEST);

        assertThrows(BadRequestException.class, () -> {
            restErrorHandler.handleError(clientHttpResponse);
        });


    }

    @Test
    public void  tesWeGetServerException() throws IOException {

        when(clientHttpResponse.getStatusCode()).thenReturn(HttpStatus.SERVICE_UNAVAILABLE);

        assertThrows(ServerException.class, () -> {
            restErrorHandler.handleError(clientHttpResponse);
        });


    }

    @Test
    public void testRestException() {

    }
}
