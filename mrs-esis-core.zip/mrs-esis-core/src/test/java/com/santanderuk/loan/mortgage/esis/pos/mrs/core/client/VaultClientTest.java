package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.ApplicationConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import static org.junit.jupiter.api.Assertions.*;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_VAULT_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName.VAULT_SERVICE;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

@ExtendWith(MockitoExtension.class)
@RestClientTest(VaultClient.class)
@ActiveProfiles("test")
@EnableConfigurationProperties({ApplicationConfig.class, AppProps.class})
class VaultClientTest {

    @Autowired
    RestTemplate yourApi;
    @Autowired
    VaultClient vaultClient;
    @MockBean
    EsisCoreEngineClient esisCoreEngineClient;
    @SpyBean
    private HelperUtilities helperUtilities;

    @Test
    void retrieveVaultDocument() {

        MockRestServiceServer server = MockRestServiceServer.createServer(yourApi);

        server.expect(requestTo("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/vault/document/retrieveByReference"))
                .andRespond((response) -> {
                    try {
                        throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, "HelperUtilities- exception while injecting doc in vault");
                    } catch (CoreServiceException e) {
                        throw new RuntimeException(e);
                    }
                });
        assertThrows(RuntimeException.class, () -> {
            vaultClient.retrieveVaultDocument("123");
        });
    }

    @Test
    void test3XXException() {
        MockRestServiceServer server = MockRestServiceServer.createServer(yourApi);

        server.expect(requestTo("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/vault/document/retrieveByReference"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.TEMPORARY_REDIRECT));
        assertThrows(CoreServiceException.class, () -> {
            vaultClient.retrieveVaultDocument("123");
        });
    }
}