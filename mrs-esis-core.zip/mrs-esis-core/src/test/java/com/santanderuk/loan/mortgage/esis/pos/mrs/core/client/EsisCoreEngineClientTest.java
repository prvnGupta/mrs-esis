package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.ApplicationConfig;
import org.apache.tomcat.util.codec.binary.Base64;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

@ExtendWith(MockitoExtension.class)
@RestClientTest(EsisCoreEngineClient.class)
@ActiveProfiles("test")
@EnableConfigurationProperties({ApplicationConfig.class, AppProps.class})
class EsisCoreEngineClientTest {

    @Autowired
    EsisCoreEngineClient esisCoreEngineClient;
    @Autowired
    private MockRestServiceServer server;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    RestTemplate yourApi;
    private ObjectMapper mapper = new ObjectMapper();

    @Test
    void retrieveKfiAsPdf() throws JsonProcessingException {
        com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response res = new com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response();
        Response.Output out = new Response.Output();
        out.setValue("what's up");
        res.setOutput(out);
        Response.KFIData kfiData = new Response.KFIData();
        kfiData.setKFIId(Arrays.toString(Base64.encodeBase64("abc".getBytes())));
        kfiData.setValue("YWJjZGVmZw==");
        res.setKFIData(kfiData);
        MockRestServiceServer server = MockRestServiceServer.createServer(yourApi);

        server.expect(requestTo("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/mortgage-sale-agreement/v1/retrieve-kfi/"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(mapper.writeValueAsString(res), MediaType.APPLICATION_JSON));
                //.body(mapper.writeValueAsString(res));
       // esisCoreEngineClient.retrieveKfiAsPdf("");
        assertThrows(CoreServiceException.class, () -> {
            esisCoreEngineClient.retrieveKfiAsPdf("");
        });
    }

    @Test
    void retrieveKfiRestClientException() throws JsonProcessingException, CoreServiceException {
        com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response res = new com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response();
        Response.Output out = new Response.Output();
        out.setValue("what's up");
        res.setOutput(out);
        Response.KFIData kfiData = new Response.KFIData();
        kfiData.setKFIId(Arrays.toString(Base64.encodeBase64("abc".getBytes())));
        kfiData.setValue("YWJjZGVmZw==");
        res.setKFIData(kfiData);
        MockRestServiceServer server = MockRestServiceServer.createServer(yourApi);

        server.expect(requestTo("https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/mortgage-sale-agreement/v1/retrieve-kfi/"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(mapper.writeValueAsString(res), MediaType.APPLICATION_XML));
        //.body(mapper.writeValueAsString(res));
        assertThrows(CoreServiceException.class, () -> {
            esisCoreEngineClient.retrieveKfiAsPdf("");
        });
    }
}