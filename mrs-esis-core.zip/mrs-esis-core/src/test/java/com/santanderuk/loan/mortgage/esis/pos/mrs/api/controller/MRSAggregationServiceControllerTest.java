package com.santanderuk.loan.mortgage.esis.pos.mrs.api.controller;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.MrsAggregationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class MRSAggregationServiceControllerTest {

    @InjectMocks
    MRSAggregationServiceController mrsAggregationServiceController;
    @Mock
    MrsAggregationService mrsAggregationService;

    @Test
    void happyPath() throws CoreServiceException {

        Response res = new Response();
        Response.Output out = new Response.Output();
        out.setValue("what's up");
        res.setOutput(out);
        Response.KFIData kfiData = new Response.KFIData();
        kfiData.setKFIId("123");
        res.setKFIData(kfiData);
        Mockito.when(mrsAggregationService.generateEsisDocument(any())).thenReturn(new Object());
        Mockito.when(mrsAggregationService.generatePDF(any())).thenReturn(res);
        Mockito.when(mrsAggregationService.ingestDocument(any(), any())).thenReturn(true);
        KFIRequest kfi = new KFIRequest();
        //kfi.setKFIReference();
        kfi.setAccount(new KFIRequest.Account());
        ResponseEntity<Response> resp = mrsAggregationServiceController.generateEsisDocument(kfi);

        assertEquals(resp.getBody().getOutput().getValue(), "");

}

}