package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


class HelperUtilitiesTest {

    //Tests added after code created as the service was not done using TDD - no functional requirements stored
    private static HelperUtilities helperUtilities;

    @BeforeAll
    static void beforeAll() {
        helperUtilities = new HelperUtilities();
    }


    @Test
    void testRestHandler() {
        try {
            helperUtilities.handleRestException("12345",new Response(),new RestClientException("Exception"),new EsisCoreEngineClient());
        } catch (CoreServiceException e) {
            e.printStackTrace();
        }
    }

    @Test
    void testRestExceptionHandler() {

            assertThrows(NullPointerException.class, () -> {
                helperUtilities.handleRestException("12345",new Response(),new HttpClientErrorException(HttpStatus.NOT_FOUND),new EsisCoreEngineClient());
            });

    }

    @Test
    void testRestException500Handler() throws CoreServiceException {

            helperUtilities.handleRestException("12345",new Response(),new HttpClientErrorException(HttpStatus.UNAUTHORIZED),new EsisCoreEngineClient());


    }

    @Test
    void testSanitize() {
        assertEquals("Hola",helperUtilities.sanitiseString("\nHola\r"));

    }


}