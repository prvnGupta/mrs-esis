package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.handler;

import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.BadRequestException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ServerException;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;

public class RestErrorHandler implements ResponseErrorHandler {

    @Override
    public boolean hasError(ClientHttpResponse clientHttpResponse) throws IOException {
        return !clientHttpResponse.getStatusCode().is2xxSuccessful();
    }

    @Override
    public void handleError(ClientHttpResponse clientHttpResponse) throws IOException {

        if (clientHttpResponse.getStatusCode().is4xxClientError()) {
            if(clientHttpResponse.getStatusCode() == HttpStatus.NOT_FOUND){
                throw new ServerException("Downstream service unavailable");
            }
            throw new BadRequestException("Bad Request to Downstream service");
        }

        if (clientHttpResponse.getStatusCode().is5xxServerError()) {
            throw new ServerException("Internal error in downstream service");
        }

    }
}
