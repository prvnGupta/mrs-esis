package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;

public class BadRequestException extends RuntimeException {

    public BadRequestException(String message){
        super(message);
    }
}
