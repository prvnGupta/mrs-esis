package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;

public enum ErrorType {
    ERROR_BASIC_VALIDATION,
    SYSTEM_ERROR,
    ERROR_ESIS_CORE_ENGINE,
    ERROR_ESIS_CORE_ENGINE_RETRIEVAL,
    ERROR_CONTENT_MISSING,
    ERROR_INVALID_DATA,
    ERROR_GMC_API,
    ERROR_VAULT_API,
    ERROR_VAULT_API_INGESTION,
    ERROR_VAULT_API_RETRIEVAL,
}
