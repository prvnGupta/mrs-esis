package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;


import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.AbbeyYN;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.KFIResponse;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ServerException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Base64Zipper;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.xml.bind.*;

import java.io.StringReader;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.*;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName.*;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.X_IBM_CLIENT_ID;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.*;


@Component
@Slf4j
public class EsisCoreEngineClient {

    static final JAXBContext context;

    static {
        try {
            context = initContext();
        } catch (JAXBException e) {
            throw new ServerException("exception in jaxb context", e);
        }
    }

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AppProps appProps;

    private static JAXBContext initContext() throws JAXBException {
        return JAXBContext.newInstance(KFIResponse.class);
    }

    public Object generateESIS(KFIRequest kfiRequest) throws CoreServiceException {
        log.info("Start - generateESIS...");
        Object response = null;
        HttpEntity<Object> entity = buildGenerateEntity(kfiRequest);
        try {
            log.debug("Preparing to send request to generate KFI");
            ResponseEntity<Object> jsonResponse = restTemplate.postForEntity(appProps.getPosCoreServiceURI(), entity, Object.class);
            log.debug("Request sent to generate esis doc : {}", kfiRequest.toString().replaceAll("[\r\n]", ""));
            response = jsonResponse.getBody();
            if (response == null) {
                log.debug("Exception found when calling KFI");
                throw new ServerException(ERR_EMPTY_ESIS_CORE_RESPONSE);
            }
        } catch (RestClientException restClientException) {
            log.error("RESTClient error: Generating ESIS - Reference : {} - Cause : {} ", kfiRequest.getKFIReference(), restClientException.getCause());
            throw new CoreServiceException(ESIS_CORE_ENGINE_SERVICE, ERROR_ESIS_CORE_ENGINE, "exception while calling POS core service");

        }
        log.info("Done - generateESIS...");
        return response;
    }

    private HttpEntity<Object> buildGenerateEntity(KFIRequest kfiRequest) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        headers.set(X_IBM_CLIENT_ID, appProps.getPosClientId());
        return new HttpEntity<>(kfiRequest, headers);
    }

    public Response retrieveKfiAsPdf(String esisId) throws CoreServiceException {
        log.info("Start - retrieveKfiAsPdf... for Reference ID : {}", sanitiseString(esisId));
        ResponseEntity<Response> response = null;
        Response finalResponse = null;
        log.debug("Building entity for Retrieve KFI");
        HttpEntity<Object> entity = buildRetrieveEntity();
        try {
            response = restTemplate.exchange(appProps.getRetrieveKfiURI() + "/" + esisId, HttpMethod.GET, entity, Response.class);
            if (response.getBody() != null) {
                log.debug("Response Code : {} ", response.getStatusCode());
                finalResponse = response.getBody();
                if (isEsisDocument(finalResponse)) {
                    log.error("Document Retrieval failed: KFI engine can't retrieve ESIS document");
                    throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API_RETRIEVAL, ERR_VAULT_RETRIEVAL);
                }
            }
        } catch (RestClientException restClientException) {
            log.error("RESTClient error: Retrieving ESIS - Reference : {}", sanitiseString(esisId));
            log.error("RESTClient error: StackTrace : {}", restClientException.getMessage());
            throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API_RETRIEVAL, "exception while retrieving kfi");
        }
        log.info("Done - retrieveKfiAsPdf... for Reference ID : {}", sanitiseString(esisId));
        return finalResponse;
    }

    private HttpEntity<Object> buildRetrieveEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(X_IBM_CLIENT_ID, appProps.getPosClientId());
        return new HttpEntity<>(headers);
    }

    private boolean isEsisDocument(Response finalResponse) throws CoreServiceException {
        log.debug("Start - checking if document received is an Esis                                                                                                                                                                                           Document...");
        boolean isEsisDoc = false;
        if (finalResponse != null && finalResponse.getKFIData() != null) {
            String kfiData = finalResponse.getKFIData().getValue();
            byte[] zipData = Base64.decodeBase64(kfiData);
            String unzipData = Base64Zipper.unzip(zipData);
            StringReader reader = new StringReader(unzipData);
            try {
                Unmarshaller unmarshaller = context.createUnmarshaller();
                KFIResponse kfiResponse = (KFIResponse) unmarshaller.unmarshal(reader);

                if (kfiResponse != null && kfiResponse.getFlags() != null &&
                        kfiResponse.getFlags().getESISDoc() == AbbeyYN.Y) {
                    isEsisDoc = true;

                }
            } catch (JAXBException e) {
                CoreServiceException coreServiceException = new CoreServiceException(ESIS_CORE_ENGINE_SERVICE, ERROR_ESIS_CORE_ENGINE, ERR_CORE_SERVICE_UNZIP);
                log.error("JAXBException error: StackTrace : {}", e.getMessage());
                throw coreServiceException;
            }
        }
        log.debug("Done - isEsisDocument...flag :{}", isEsisDoc);
        return isEsisDoc;
    }

    private String sanitiseString(String str) {
        return str.replaceAll("[\r\n]", "");
    }
}
