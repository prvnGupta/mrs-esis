/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.core.util;

/**
 * Created by C0251500 on 15/12/2017
 * Description :
 */
public class Constants {

    public static final String ESIS_CORE_REQUEST = "esis.core.request.domain.object";
    public static final String ESIS_CORE_RESPONSE = "esis.core.response.domain.object";

    public static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";
    public static final String X_IBM_PARENT_CLIENT_ID = "X-IBM-Parent-Client-Id";

    public static final String EMPTY_STRING = "";
    public static final String YES = "Y";
    public static final String NO = "N";
    public static final String SPACE_STRING = " ";
    public static final String AND = " and ";
    public static final String COMMA_SEPARATED = ", ";


    public static final String GMC_DATE_FORMAT = "yyyyMMdd";
    public static final String GMC_DATE_TIMEZONE = "GMT";

    /* Mortgage Category */
    public static final String CAT_STANDARD = "A";
    public static final String STANDARD_ANMF = "B";
    public static final String EQUITY_RELEASE = "E";
    public static final String FLEXI = "F";
    public static final String SECURED_LENDING = "S";

    /* Mortgage category accepted Range*/
    public static final String CLASSIC = "C";
    public static final String CAT = "CA";
    public static final String LIFE_TIME = "E";
    public static final String LIFE_STYLE = "L";
    public static final String OFFSET_FLEXI = "O";
    public static final String STANDARD = "S";

    public static final String DIRECT_INTRO_ADVISE = "R";
    public static final String NON_DIRECT_INTRO_ADVISE = "N";
    public static final String UNKNOWN = "U";

    public static final String MIXED_RATE = "MIXED_RATE";

    /* Document Type */
    public static final String PRODUCT_CONVERSION_QUOTE = "1";
    public static final String NEW_LENDING_QUOTE = "2";
    public static final String SL_TO_ANMF_CONVERSION_OFFER = "3";
    public static final String ANMF_TO_ANMF_CONVERSION_OFFER = "4";
    public static final String FAST_TRACK_CONVERSION_OFFER = "5";

    /* ESIS Types */
    public static final String ILLUSTRATION = "Illustration";
    public static final String OFFER = "Offer";

    /* Prod Condition Code */

    public static final String C_6001 = "6001";
    public static final String C_6002 = "6002";
    public static final String C_6003 = "6003";
    public static final String C_6004 = "6004";
    public static final String C_6005 = "6005";
    public static final String C_6006 = "6006";
    public static final String C_6007 = "6007";
    public static final String C_6008 = "6008";
    public static final String C_6009 = "6009";
    public static final String C_6010 = "6010";
    public static final String C_6011 = "6011";
    public static final String C_6012 = "6012";
    public static final String C_6013 = "6013";
    public static final String C_6014 = "6014";
    public static final String C_6016 = "6016";
    public static final String C_6017 = "6017";
    public static final String C_6018 = "6018";
    public static final String C_6019 = "6019";
    public static final String C_6020 = "6020";
    public static final String C_6021 = "6021";
    public static final String C_6022 = "6022";
    public static final String C_6023 = "6023";
    public static final String C_6029 = "6029";
    public static final String C_6030 = "6030";
    public static final String C_6031 = "6031";
    public static final String C_6032 = "6032";
    public static final String C_6033 = "6033";
    public static final String C_6072 = "6072";
    public static final String C_6073 = "6073";
    public static final String C_6101 = "6101";
    public static final String C_6201 = "6201";
    public static final String C_6206 = "6206";

    /* Repayment TYPE */
    public static final Integer REPAYMENT = 1;
    public static final Integer INTEREST_ONLY = 2;
    public static final Integer ENDOWMENT = 3;
    public static final Integer INTEREST_ONLY_PURE = 4;
    public static final Integer INTEREST_ONLY_PENSION = 5;
    public static final Integer INTEREST_ONLY_INVESTMENT_LINKED = 6;

    /* Repayment Method */
    public static final String REPAYMENT_METHOD = "Repayment";
    public static final String INTEREST_ONLY_METHOD = "Interest Only";

    /* Product Step ID */
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";

    /* Bonus Description */
    public static final String MOVER_SOLUTION = "MOVER SOLUTION";
    public static final String REFUNDVAL = "REFUNDVAL";
    public static final String HOMEBUYER = "HOMEBUYER PLUS SOLUTION";

    /* Bonus Condition Code */
    public static final String BONUS_2065 = "2065";
    public static final String BONUS_2556 = "2556";
    public static final String BONUS_2591 = "2591";
    public static final String BONUS_2650 = "2650";
    public static final String BONUS_2667 = "2667";
    public static final String BONUS_7001 = "7001";

    /* Fee Payment Status */
    public static final String TO_BE_ADDED_TO_LOAN = "A";
    public static final String TO_BE_PAID = "B";
    public static final String COLLECTED_ON_ACCEPTANCE_DEBIT_CREDIT = "C";
    public static final String PAID = "P";

    /* Fee types */
    public static final String FEE_IM = "IM";
    public static final String FEE_CB = "CB";
    public static final String FEE_SE = "SE";
    public static final String FEE_RD = "RD";
    public static final String FEE_VL = "VL";
    public static final String FEE_CV = "CV";
    public static final String FEE_SL = "SL";
    public static final String FEE_SA = "SA";
    public static final String FEE_SD = "SD";
    public static final String FEE_CH = "CH";
    public static final String FEE_CM = "CM";
    public static final String FEE_OT = "OT";
    public static final String FEE_LT = "LT";
    public static final String FEE_SF = "SF";
    public static final String FEE_SM = "SM";
    public static final String FEE_PR = "PR";
    public static final String FEE_CL = "CL";
    public static final String FEE_IT = "IT";
    public static final String FEE_TC = "TC";


    public static final String X = "X";

    public static final String BTL_B = "B";
    public static final String BTL_C = "C";
    public static final String BTL_N = "N";

    /* CV Change Indicator */
    public static final String TERM_CHANGE = "T";
    public static final String METHOD_OF_REPAYMENT_CHANGE = "R";
    public static final String BOTH_TERM_REPAYMENT_CHANGE = "B";


    public static final String QUOTATION_REFERENCE_NUMBER = "QuotationReferenceNumber";
    public static final String TRUE = "True";
    public static final String FALSE_STRING = "False";
    public static final String PDF_FORMAT = "PDF";
    public static final String ESIS_DOCUMENT_DATA = "DocumentData";

    /* GASS Constants */
    public static final String CDATA_START = "<![CDATA[";
    public static final String CDATA_END = "]]>";
    public static final String GENERATE_ESIS = "Generate_ESIS_Offer_Doc";
    public static final String REQUEST_ESIS = "Request_ESIS_Offer_Doc";







}
