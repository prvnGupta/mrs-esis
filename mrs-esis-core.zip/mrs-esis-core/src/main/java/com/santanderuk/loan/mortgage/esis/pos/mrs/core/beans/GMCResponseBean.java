package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

/**
 * Created by C0251500 on 21/03/2018
 * Description :
 */
public class GMCResponseBean {
    private String payload;

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "GMCResponseBean{" +
                "payload='" + payload + '\'' +
                '}';
    }
}
