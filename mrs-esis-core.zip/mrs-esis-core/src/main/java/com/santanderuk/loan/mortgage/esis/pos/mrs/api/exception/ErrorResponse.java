package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;

import lombok.Getter;

import javax.xml.bind.annotation.*;
import java.util.Date;


@XmlRootElement(name = "errorResponse")
@XmlType(propOrder = { "error", "date", "description", "moreInformation" })
@XmlAccessorType(XmlAccessType.FIELD)
@Getter
public class ErrorResponse {

    @XmlElement(name = "error", required = true)
    private String error;

    @XmlElement(name = "date")
    private Date date;

    @XmlElement(name = "description", required = true)
    private String description;

    @XmlElement(name = "moreInformation")
    private String moreInformation;


    public ErrorResponse() {
    }

    public ErrorResponse(String error, Date date, String description, String moreInformation) {
        this.error = error;
        this.date = new Date(date.getTime());
        this.description = description;
        this.moreInformation = moreInformation; 
    }

}
