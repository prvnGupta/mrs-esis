package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

/**
 * Created by C0251500 on 06/06/2018
 * Description :
 */
public class VaultRetrieveResponseBean {
    private String binaries;

    public String getBinaries() {
        return binaries;
    }

    public void setBinaries(String binaries) {
        this.binaries = binaries;
    }

    @Override
    public String toString() {
        return "VaultRetrieveResponseBean{" +
                "binaries='" + binaries + '\'' +
                '}';
    }
}
