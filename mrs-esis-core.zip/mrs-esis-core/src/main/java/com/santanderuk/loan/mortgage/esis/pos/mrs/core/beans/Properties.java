
package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "doc:accountNumber",
    "doc:sortCode",
    "doc:productType_",
    "doc:standardReference",
    "doc:entity",
    "doc:productSubType_",
    "doc:companyCode",
    "doc:communicationType_",
    "doc:internalAccountNumber",
    "doc:brand",
    "dc:description",
    "doc:applicationGroup",
    "doc:applicationName",
    "doc:priority"
})
public class Properties {

    @JsonProperty("doc:accountNumber")
    private String docAccountNumber;
    @JsonProperty("doc:sortCode")
    private String docSortCode;
    @JsonProperty("doc:productType_")
    private String docProductType;
    @JsonProperty("doc:standardReference")
    private String docStandardReference;
    @JsonProperty("doc:entity")
    private String docEntity;
    @JsonProperty("doc:productSubType_")
    private String docProductSubType;
    @JsonProperty("doc:companyCode")
    private String docCompanyCode;
    @JsonProperty("doc:communicationType_")
    private String docCommunicationType;
    @JsonProperty("doc:internalAccountNumber")
    private String docInternalAccountNumber;
    @JsonProperty("doc:brand")
    private String docBrand;
    @JsonProperty("dc:description")
    private String dcDescription;
    @JsonProperty("doc:applicationGroup")
    private String docApplicationGroup;
    @JsonProperty("doc:applicationName")
    private String docApplicationName;
    @JsonProperty("doc:priority")
    private String docPriority;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("doc:accountNumber")
    public String getDocAccountNumber() {
        return docAccountNumber;
    }

    @JsonProperty("doc:accountNumber")
    public void setDocAccountNumber(String docAccountNumber) {
        this.docAccountNumber = docAccountNumber;
    }

    @JsonProperty("doc:sortCode")
    public String getDocSortCode() {
        return docSortCode;
    }

    @JsonProperty("doc:sortCode")
    public void setDocSortCode(String docSortCode) {
        this.docSortCode = docSortCode;
    }

    @JsonProperty("doc:productType_")
    public String getDocProductType() {
        return docProductType;
    }

    @JsonProperty("doc:productType_")
    public void setDocProductType(String docProductType) {
        this.docProductType = docProductType;
    }

    @JsonProperty("doc:standardReference")
    public String getDocStandardReference() {
        return docStandardReference;
    }

    @JsonProperty("doc:standardReference")
    public void setDocStandardReference(String docStandardReference) {
        this.docStandardReference = docStandardReference;
    }

    @JsonProperty("doc:entity")
    public String getDocEntity() {
        return docEntity;
    }

    @JsonProperty("doc:entity")
    public void setDocEntity(String docEntity) {
        this.docEntity = docEntity;
    }

    @JsonProperty("doc:productSubType_")
    public String getDocProductSubType() {
        return docProductSubType;
    }

    @JsonProperty("doc:productSubType_")
    public void setDocProductSubType(String docProductSubType) {
        this.docProductSubType = docProductSubType;
    }

    @JsonProperty("doc:companyCode")
    public String getDocCompanyCode() {
        return docCompanyCode;
    }

    @JsonProperty("doc:companyCode")
    public void setDocCompanyCode(String docCompanyCode) {
        this.docCompanyCode = docCompanyCode;
    }

    @JsonProperty("doc:communicationType_")
    public String getDocCommunicationType() {
        return docCommunicationType;
    }

    @JsonProperty("doc:communicationType_")
    public void setDocCommunicationType(String docCommunicationType) {
        this.docCommunicationType = docCommunicationType;
    }

    @JsonProperty("doc:internalAccountNumber")
    public String getDocInternalAccountNumber() {
        return docInternalAccountNumber;
    }

    @JsonProperty("doc:internalAccountNumber")
    public void setDocInternalAccountNumber(String docInternalAccountNumber) {
        this.docInternalAccountNumber = docInternalAccountNumber;
    }

    @JsonProperty("doc:brand")
    public String getDocBrand() {
        return docBrand;
    }

    @JsonProperty("doc:brand")
    public void setDocBrand(String docBrand) {
        this.docBrand = docBrand;
    }

    @JsonProperty("dc:description")
    public String getDcDescription() {
        return dcDescription;
    }

    @JsonProperty("dc:description")
    public void setDcDescription(String dcDescription) {
        this.dcDescription = dcDescription;
    }

    @JsonProperty("doc:applicationGroup")
    public String getDocApplicationGroup() {
        return docApplicationGroup;
    }

    @JsonProperty("doc:applicationGroup")
    public void setDocApplicationGroup(String docApplicationGroup) {
        this.docApplicationGroup = docApplicationGroup;
    }

    @JsonProperty("doc:applicationName")
    public String getDocApplicationName() {
        return docApplicationName;
    }

    @JsonProperty("doc:applicationName")
    public void setDocApplicationName(String docApplicationName) {
        this.docApplicationName = docApplicationName;
    }

    @JsonProperty("doc:priority")
    public String getDocPriority() {
        return docPriority;
    }

    @JsonProperty("doc:priority")
    public void setDocPriority(String docPriority) {
        this.docPriority = docPriority;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
