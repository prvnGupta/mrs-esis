package com.santanderuk.loan.mortgage.esis.pos.mrs.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class AppProps {

    @Value("${core-api.service.pos-core-service.uri}")
    private String posCoreServiceURI;
    @Value("${core-api.service.pos-core-service.retrieve-kfi-uri}")
    private String retrieveKfiURI;
    @Value("${core-api.service.pos-core-service.client-id}")
    private String posClientId;

    @Value("${core-api.service.gmc-core-service.uri-base64}")
    private String gmcCoreServiceURIBase64;
    @Value("${core-api.service.gmc-core-service.client-id}")
    private String gmcClientId;
    @Value("${core-api.service.gmc-core-service.document-code}")
    private String gmcDocumentCode;
    @Value("${core-api.service.gmc-core-service.template}")
    private String gmcTemplate;

    @Value("${core-api.service.vault-document-service.uri-ingest}")
    private String vaultDocumentServiceCreateURI;
    @Value("${core-api.service.vault-document-service.uri-retrieve}")
    private String vaultDocumentServiceRetrieveURI;
    @Value("${core-api.service.vault-document-service.uri-search}")
    private String vaultDocumentServiceSearchURI;
    @Value("${core-api.service.vault-document-service.client-id}")
    private String vaultDocumentServiceClientId;


    public String getPosCoreServiceURI() {
        return posCoreServiceURI;
    }

    public String getGmcCoreServiceURIBase64() {
        return gmcCoreServiceURIBase64;
    }

    public String getGmcClientId() {
        return gmcClientId;
    }

    public String getGmcDocumentCode() {
        return gmcDocumentCode;
    }

    public String getGmcTemplate() {
        return gmcTemplate;
    }

    public String getRetrieveKfiURI() {
        return retrieveKfiURI;
    }

    public String getVaultDocumentServiceCreateURI() {
        return vaultDocumentServiceCreateURI;
    }

    public String getVaultDocumentServiceRetrieveURI() {
        return vaultDocumentServiceRetrieveURI;
    }

    public String getVaultDocumentServiceClientId() {
        return vaultDocumentServiceClientId;
    }

    public String getPosClientId() { return posClientId; }

    public String getVaultDocumentServiceSearchURI() {
        return vaultDocumentServiceSearchURI;
    }


}

