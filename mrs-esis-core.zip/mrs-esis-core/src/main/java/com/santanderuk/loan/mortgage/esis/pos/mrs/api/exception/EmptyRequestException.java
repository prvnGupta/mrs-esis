package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;

public class EmptyRequestException extends RuntimeException {

    public EmptyRequestException(String message){
        super(message);
    }
}
