package com.santanderuk.loan.mortgage.esis.pos.mrs.api.service;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.EsisCoreEngineClient;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.GmcClient;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.client.VaultClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MrsAggregationService {

    @Autowired
    private EsisCoreEngineClient esisCoreEngineClient;

    @Autowired
    private GmcClient gmcClient;

    @Autowired
    private VaultClient vaultClient;

    public Object generateEsisDocument(KFIRequest kfiRequest) throws CoreServiceException {
        return esisCoreEngineClient.generateESIS(kfiRequest);
    }

    public Response generatePDF(Object request) throws CoreServiceException {
        return gmcClient.generateTemplateAsPDF(request);
    }

    public Boolean ingestDocument(KFIRequest request, Response gmcResponse) throws CoreServiceException {
        return vaultClient.ingestDocumentToVault(request, gmcResponse);
    }

    public Response retrieveEsisAsPdf(String kfiId) throws CoreServiceException {
        return vaultClient.retrieveVaultDocument(kfiId);
    }


}
