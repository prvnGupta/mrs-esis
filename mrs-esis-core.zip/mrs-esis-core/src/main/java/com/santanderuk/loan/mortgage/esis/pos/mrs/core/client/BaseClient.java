package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.*;

public class BaseClient {

    protected Response populateResponseBean(String kfiReference, String base64String){
        Response response = new Response();
        Response.KFIData kfiData = new Response.KFIData();
        kfiData.setKFIId(kfiReference);
        kfiData.setBase64Encoded(TRUE);
        kfiData.setGZipCompressed(FALSE_STRING);
        kfiData.setValue(EMPTY_STRING);

        Response.Output output = new Response.Output();
        output.setType(PDF_FORMAT);
        output.setBase64Encoded(TRUE);
        output.setGZipCompressed(FALSE_STRING);
        output.setValue(base64String);

        response.setKFIData(kfiData);
        response.setOutput(output);
        return response;
    }

}
