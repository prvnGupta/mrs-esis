/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

/**
 * Created by C0251500 on 11/09/2017
 * Description :
 */
@ServletComponentScan(basePackages = "com.santanderuk.loan.mortgage.esis.pos.mrs.api.controller")
@SpringBootApplication(scanBasePackages = {"com.santanderuk.loan.mortgage.esis.pos.mrs"})
public class MRSAggregationServiceApplication {
    public static void main(String args[]) {
        SpringApplication.run(MRSAggregationServiceApplication.class, args);
    }
}
