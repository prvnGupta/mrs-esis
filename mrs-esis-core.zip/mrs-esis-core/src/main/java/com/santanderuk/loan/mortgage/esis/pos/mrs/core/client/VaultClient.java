package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_VAULT_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName.VAULT_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.EMPTY_STRING;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.X_IBM_CLIENT_ID;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_CORE_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_VAULT_RETRIEVAL;


@Component
@Slf4j
public class VaultClient extends BaseClient {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AppProps appProps;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EsisCoreEngineClient esisCoreEngineClient;

    @Autowired
    private HelperUtilities helperUtilities;

    public Response retrieveVaultDocument(String kfiId) throws CoreServiceException {
        log.info("Start - retrieveVaultDocument... for Reference ID: {}", helperUtilities.sanitiseString(kfiId));
        String vaultResponse;
        Response response = null;

        try {

            log.info("Generating headers for Vault request");
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(X_IBM_CLIENT_ID, appProps.getVaultDocumentServiceClientId());
            HttpEntity<Object> entity = new HttpEntity<>(populateVaultRetrieveBean(kfiId), headers);

            log.debug("Start - retrieval service call");
            ResponseEntity<VaultRetrieveResponseBean> jsonResponse = restTemplate.postForEntity(appProps.getVaultDocumentServiceRetrieveURI(), entity, VaultRetrieveResponseBean.class);
            if (null == jsonResponse) {
                log.debug("Vault service call - COMPLETED with NO RESPONSE - Reference : {}", helperUtilities.sanitiseString(kfiId));
                throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_VAULT_RETRIEVAL);
            }
            log.debug("Done - retrieval service call");

            if (jsonResponse.getStatusCode().is2xxSuccessful()) {
                log.info("ESIS Document retrieved Successfully - Reference: {} ", helperUtilities.sanitiseString(kfiId));
                vaultResponse = jsonResponse.getBody().getBinaries();
                response = populateResponseBean(kfiId, vaultResponse);
            } else if (jsonResponse.getStatusCode().is3xxRedirection()) {
                log.error("Vault-Nuxeo Service call - error : Multiple document retrieved for ESIS reference - {}", helperUtilities.sanitiseString(kfiId));
                throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_VAULT_RETRIEVAL);
            }
        } catch (RestClientException restClientException) {
            response = helperUtilities.handleRestException(kfiId, response, restClientException, esisCoreEngineClient);
        }
        log.info("Done - retrieveVaultDocument... for Reference ID: {}", helperUtilities.sanitiseString(kfiId));
        return response;
    }



    public Boolean ingestDocumentToVault(KFIRequest request, Response response) throws CoreServiceException {
        log.info("Start - ingestDocumentToVault... ESIS reference: {}", response.getKFIData().getKFIId());
        String esisReference = EMPTY_STRING;
        try {
            log.info("Ingesting Document to Vault");
            esisReference = response.getKFIData().getKFIId();
            String accountNumber = EMPTY_STRING;
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(X_IBM_CLIENT_ID, appProps.getVaultDocumentServiceClientId());
            log.info("Request headers generated");
            if (request != null && request.getAccount() != null) {
                accountNumber = request.getAccount().getReference();
            }
            HttpEntity<Object> entity = new HttpEntity<>(populateVaultIngestBean(accountNumber, response), headers);
            log.debug("Start - Ingesting into Vault call");
            restTemplate.postForEntity(appProps.getVaultDocumentServiceCreateURI(), entity, VaultIngestResponseBean.class);
            log.debug("Done - Ingesting into Vault for ESIS reference : {}", esisReference);

        } catch (RestClientException restClientException) {
            log.error("RESTClient error: VAULT service INGEST document failed for ESIS reference : {}", esisReference);
            throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, "exception while calling ingest document service");
        }

        log.info("Done - ingestDocumentToVault... ESIS reference: {}", helperUtilities.sanitiseString(response.getKFIData().getKFIId()));
        return Boolean.TRUE;
    }

    private String populateVaultRetrieveBean(String kfiId) throws CoreServiceException {
        log.debug("Start - populateVaultRetrieveBean...");
        String vaultRequest;
        VaultRetrieveBean retrieveBean = new VaultRetrieveBean();
        retrieveBean.setUid(kfiId);
        try {
            vaultRequest = objectMapper.writeValueAsString(retrieveBean);
        } catch (JsonProcessingException e) {
            log.error("JsonProcessingException: StackTrace: {}", e.getMessage());
            throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_VAULT_RETRIEVAL);
        }
        log.debug("Start - populateVaultRetrieveBean...");
        return vaultRequest;
    }

    private String populateVaultIngestBean(String accountNumber, Response gmcResponse) throws CoreServiceException {
        log.debug("Start - populateVaultIngestBean...");
        String vaultRequest;
        VaultIngestBean ingestBean = new VaultIngestBean();
        ingestBean.setFile(gmcResponse.getOutput().getValue());
        ingestBean.setFileType("application/pdf");
        ingestBean.setName(gmcResponse.getKFIData().getKFIId());
        ingestBean.setInCustomerFacing(true); // ESIS documents always go into Customer folder.

        Document document = new Document();
        Properties properties = new Properties();
        log.info("Setting properties");
        properties.setDocStandardReference(gmcResponse.getKFIData().getKFIId());
        properties.setDocAccountNumber(accountNumber);
        properties.setDocSortCode(EMPTY_STRING);
        properties.setDocEntity("RETAIL");
        properties.setDocProductSubType("300");
        properties.setDocProductType(EMPTY_STRING);
        properties.setDocCompanyCode("0015");
        properties.setDocCommunicationType("2435");
        properties.setDocInternalAccountNumber(EMPTY_STRING);
        properties.setDocBrand("Retail");
        properties.setDcDescription("Santander Mortgage ESIS");
        properties.setDocApplicationGroup("EDOC");
        properties.setDocApplicationName("ESIS");
        properties.setDocPriority("3");
        document.setProperties(properties);
        ingestBean.setDocument(document);
        log.info("population of Vault ingest Bean completed");
        try {
            log.info("creating Vault Request");
            vaultRequest = objectMapper.writeValueAsString(ingestBean);
        } catch (JsonProcessingException exception) {
            log.error("Error while creating vault request from ingestBean: " +
                            "VAULT_SERVICE: " + VAULT_SERVICE +
                            "ERROR_VAULT_API " + ERROR_VAULT_API +
                            "ERR_CORE_SERVICE " + ERR_CORE_SERVICE,
                    exception);
            throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, ERR_CORE_SERVICE);
        }
        log.debug("Done - populateVaultIngestBean...");
        return vaultRequest;
    }


}
