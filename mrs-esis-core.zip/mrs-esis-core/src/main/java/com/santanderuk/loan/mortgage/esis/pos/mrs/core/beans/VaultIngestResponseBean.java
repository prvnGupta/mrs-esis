package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

/**
 * Created by C0251500 on 27/06/2018
 * Description :
 */
public class VaultIngestResponseBean {

    private String uid;
    private String state;

    public VaultIngestResponseBean() {
    }

    public VaultIngestResponseBean(String uid, String state) {
        this.uid = uid;
        this.state = state;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
