package com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception;


import com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName;
import lombok.Getter;

@Getter
public class CoreServiceException extends Exception {

    private ServiceName serviceName;
    private ErrorType errorType;

    public ServiceName getServiceName() {
        return serviceName;
    }

    public CoreServiceException(ServiceName serviceName, ErrorType errorType, String moreInformation) {
        super(moreInformation);
        this.serviceName = serviceName;
        this.errorType = errorType;
    }

}

