package com.santanderuk.loan.mortgage.esis.pos.mrs.api.controller;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.request.KFIRequest;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.*;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.MrsAggregationService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.builder.RecursiveToStringStyle;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.EMPTY_STRING;


@RestController
@Slf4j
public class MRSAggregationServiceController {

    private static final  Logger LOG = LoggerFactory.getLogger(MRSAggregationServiceController.class);

    @Autowired
    private MrsAggregationService mrsAggregationService;

    @ApiOperation("Endpoint to create a new Esis PDF document")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Response.class),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(path="/esis/create",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_XML_VALUE,
            produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Response> generateEsisDocument(@RequestBody KFIRequest posRequest) throws CoreServiceException {

        checkEmptyRequest(posRequest);

        LOG.info(posRequest.getAccount().getReference());

        LOG.info("Start - Invoking MRS Service");
        Object esisCoreResponse =  mrsAggregationService.generateEsisDocument(posRequest);
        // error in below log print- java.lang.reflect.InaccessibleObjectException: Unable to make field final boolean java.util.LinkedHashMap.accessOrder accessible: module
       // LOG.debug("KFI json resp- {}", ReflectionToStringBuilder.toString(esisCoreResponse, new RecursiveToStringStyle()));
        LOG.debug("Done - Invoking MRS Service : ESIS document generated, now calling GMC to generate PDF template");
        Response mrsResponse = mrsAggregationService.generatePDF(esisCoreResponse);

        LOG.info("Done - PDF template generated - Now, Ingesting document into Nuxeo-Vault");
        mrsAggregationService.ingestDocument(posRequest, mrsResponse);
        LOG.info("Done - ESIS document ingested into Nuxeo-Vault- ESIS Reference ID - {}", mrsResponse.getKFIData().getKFIId());

        /* Removing PDF from response */
        Response.Output out = mrsResponse.getOutput();
        out.setValue(EMPTY_STRING);
        mrsResponse.setOutput(out);

        return new ResponseEntity<>(mrsResponse, HttpStatus.CREATED);
    }

    private void checkEmptyRequest(KFIRequest posRequest) throws EmptyRequestException{
        if (null == posRequest.getAccount()) {
            throw new EmptyRequestException("Empty request found");
        }
    }

    @ApiOperation(value = "Endpoint to retrieve KFI as PDF for given Kfi Id")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = Response.class),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })

    @RequestMapping(path = "/esis/{esisId}", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Response> getEsisDocument(@PathVariable(name = "esisId") String esisId) throws CoreServiceException {

        String esisIdToLog = esisId.replaceAll("[\r\n]","");

        LOG.info("Start - Calling to retrieve unique KFI/ESIS ID : {}", esisIdToLog);
        Response response = mrsAggregationService.retrieveEsisAsPdf(esisId);
        LOG.info("Done - Calling to retrieve unique KFI/ESIS ID : {}", esisIdToLog);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ExceptionHandler(ServerException.class)
    public ResponseEntity<ErrorResponse> handleServerException(ServerException serverException){

        ErrorResponse errorResponse = new ErrorResponse(serverException.getMessage(), new Date(), serverException.getLocalizedMessage(), "");
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(CoreServiceException.class)
    public ResponseEntity<ErrorResponse> handleCoreServiceException(CoreServiceException serverException){

        ErrorResponse errorResponse = new ErrorResponse(serverException.getMessage(), new Date(), serverException.getLocalizedMessage(), "");
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponse> handleBadRequest(BadRequestException badRequestException){

        ErrorResponse errorResponse = new ErrorResponse(badRequestException.getMessage(), new Date(), badRequestException.getLocalizedMessage(), "");
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EmptyRequestException.class)
    public ResponseEntity<ErrorResponse> handleEmptyRequest(EmptyRequestException emptyRequestException){

        ErrorResponse errorResponse = new ErrorResponse(emptyRequestException.getMessage(), new Date(), emptyRequestException.getLocalizedMessage(), "");
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_ACCEPTABLE);
    }


}
