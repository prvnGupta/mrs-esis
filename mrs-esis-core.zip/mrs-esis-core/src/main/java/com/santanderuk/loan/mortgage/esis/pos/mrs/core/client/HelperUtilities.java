package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;

import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_VAULT_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName.VAULT_SERVICE;

@Component
@Slf4j
public class HelperUtilities {
    public Response handleRestException(String kfiId, Response response, RestClientException restClientException, EsisCoreEngineClient esisCoreEngineClient) throws CoreServiceException {
        log.info("vault helper utilities exception handling");
        if (restClientException instanceof RestClientResponseException) {
            log.error("Vault-Nuxeo : Rest Client Exception : {}", restClientException.getMessage());
            if (((RestClientResponseException) restClientException).getRawStatusCode() == HttpStatus.NOT_FOUND.value()) {
                log.info("ESIS Document not found in Vault-Nuxeo - Reference : {} ", sanitiseString(kfiId));
                log.info("Start - Invoking Kfi engine Api retrieval service");
                response = esisCoreEngineClient.retrieveKfiAsPdf(kfiId);
                log.info("Done - Invoking Kfi engine Api retrieval service: Document found with reference: {}", sanitiseString(kfiId));
            } else {
                log.error("-- RESTClient error: Vault-Nuxeo service issue while retrieving : ESIS reference - {}", sanitiseString(kfiId));
            }
        } else {
            log.error("** RESTClient error: Vault-Nuxeo service issue while retrieving : ESIS reference - {}", sanitiseString(kfiId));
            log.error("** Vault-Nuxeo : Rest Client Exception : StackTrace:= {}", restClientException.getMessage());
        }
        if (response == null) {
            throw new CoreServiceException(VAULT_SERVICE, ERROR_VAULT_API, "HelperUtilities- exception while calling vault retrieval");
        }
        return response;
    }

    public String sanitiseString(String str) {
        return str.replaceAll("[\r\n]", "");
    }

}
