package com.santanderuk.loan.mortgage.esis.pos.mrs.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.handler.RestErrorHandler;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
@ConfigurationProperties
public class ApplicationConfig {

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setErrorHandler(new RestErrorHandler());

        return restTemplate;
    }

    @Bean
    public ObjectMapper customeObjectMapper(){
        return new ObjectMapper();
    }


}
