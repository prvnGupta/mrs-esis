/*
 *  ESIS, mortgage document
 *  Copyright (C) 2017-2020 Sanatander
 *  mailto:contact Santander UK com
 *
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 * This is temporary text comment and copyrights
 *
 */

package com.santanderuk.loan.mortgage.esis.pos.mrs.api.service;

public enum ServiceName {

    ESIS_CORE_ENGINE_SERVICE("ESIS core service failure"),
    GMC_SERVICE("CCM service failure"),
    VAULT_SERVICE("Vault - Nuxeo service failure"),
    MORTGAGE_ACCOUNT_SERVICE("Mortgage Account service failure"),
    ;

    private String _identifier;

    ServiceName(String identifier) {
        this._identifier = identifier;
    }

    public String identifier() {
        return _identifier;
    }
}
