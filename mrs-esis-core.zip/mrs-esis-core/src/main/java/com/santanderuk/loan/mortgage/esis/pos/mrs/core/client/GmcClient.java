package com.santanderuk.loan.mortgage.esis.pos.mrs.core.client;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.loan.mortgage.esis.aggregationservice.schema.response.mrs.Response;
import com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.CoreServiceException;
import com.santanderuk.loan.mortgage.esis.pos.mrs.config.AppProps;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.GMCRequestBean;
import com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans.GMCResponseBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;

import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_ESIS_CORE_ENGINE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.exception.ErrorType.ERROR_GMC_API;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName.ESIS_CORE_ENGINE_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.api.service.ServiceName.GMC_SERVICE;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.Constants.*;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_CORE_RESPONSE_BAD_FORMAT;
import static com.santanderuk.loan.mortgage.esis.pos.mrs.core.util.ErrorConstants.ERR_GMC_BAD_RESPONSE;

@Component
@Slf4j
public class GmcClient extends BaseClient {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AppProps appProps;

    @Autowired
    private ObjectMapper objectMapper;

    public Response generateTemplateAsPDF(Object esisResponse) throws CoreServiceException {
        log.info("Start - generateTemplateAsPDF...");
        String gmcResponse = null;
        String esisReference = null;
        try {
            if (esisResponse instanceof LinkedHashMap) {
                esisReference = (String) ((LinkedHashMap<?, ?>) ((LinkedHashMap<?, ?>) esisResponse).get(ESIS_DOCUMENT_DATA)).get(QUOTATION_REFERENCE_NUMBER);
                log.debug("ESIS Reference to generate ESIS pdf :- {}", esisReference);
            } else {
                CoreServiceException coreServiceException = new CoreServiceException(ESIS_CORE_ENGINE_SERVICE, ERROR_ESIS_CORE_ENGINE, ERR_CORE_RESPONSE_BAD_FORMAT);
                log.error("ESIS response parsing error : ServiceName : {} - Message : {} ", coreServiceException.getServiceName(), coreServiceException.getMessage());
                throw coreServiceException;
            }
            log.info("Generating headers for GMC request");
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set(X_IBM_CLIENT_ID, appProps.getGmcClientId());
            HttpEntity<Object> entity = new HttpEntity<>(populateGMCBean(esisResponse), headers);

            log.info("Start - GMC service call");
            ResponseEntity<GMCResponseBean> jsonResponse = restTemplate.postForEntity(appProps.getGmcCoreServiceURIBase64(), entity, GMCResponseBean.class);
            GMCResponseBean gmcResponseBean = jsonResponse.getBody();

            log.debug("Have response back from CCM  : {}", jsonResponse.getStatusCode());
            if (null == gmcResponseBean) {
                CoreServiceException coreServiceException = new CoreServiceException(GMC_SERVICE, ERROR_GMC_API, ERR_GMC_BAD_RESPONSE);
                log.error("CCM response error - No response from CCM service");
                throw coreServiceException;
            }
            log.info("Done - GMC service call");
            gmcResponse = gmcResponseBean.getPayload();

            log.info("Done - generateTemplateAsPDF...");

        } catch (RestClientException restClientException) {
            log.error("RESTClient error: Generating ESIS pdf - Reference ID : {}", esisReference);
            log.error("RESTClient error: Generating ESIS pdf - StackTrace : {}", restClientException.getMessage());
            throw new CoreServiceException(GMC_SERVICE, ERROR_GMC_API, "exception while calling GMC core service");
        }
        log.info("Done - generateTemplateAsPDF...");

        return populateResponseBean(esisReference, gmcResponse);
    }

    private String populateGMCBean(Object object) throws CoreServiceException {
        log.debug("Start - populateGMCBean...");
        String gmcRequest;
        GMCRequestBean gmcRequestBean = new GMCRequestBean();
        gmcRequestBean.setDocumentCode(appProps.getGmcDocumentCode());
        gmcRequestBean.setTemplate(appProps.getGmcTemplate());
        gmcRequestBean.setVariables(object);
        try {
            gmcRequest = objectMapper.writeValueAsString(gmcRequestBean);
        } catch (JsonProcessingException e) {
            CoreServiceException coreServiceException = new CoreServiceException(GMC_SERVICE, ERROR_GMC_API, ERR_GMC_BAD_RESPONSE);
            log.error("Json ParseException : {} ", e.getMessage());
            throw coreServiceException;
        }
        log.debug("Request to GMC client : {}", gmcRequest);
        return gmcRequest;
    }
}
