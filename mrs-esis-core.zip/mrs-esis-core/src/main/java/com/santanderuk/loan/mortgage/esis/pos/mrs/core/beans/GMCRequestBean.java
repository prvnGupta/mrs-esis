package com.santanderuk.loan.mortgage.esis.pos.mrs.core.beans;

/**
 * Created by C0251500 on 13/03/2018
 * Description :
 */
public class GMCRequestBean {

    private String template;
    private String documentCode;
    private Object variables;

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public Object getVariables() {
        return variables;
    }

    public void setVariables(Object variables) {
        this.variables = variables;
    }

    @Override
    public String toString() {
        return "GMCRequestBean{" +
                "template='" + template + '\'' +
                ", documentCode='" + documentCode + '\'' +
                ", variables=" + variables +
                '}';
    }
}
